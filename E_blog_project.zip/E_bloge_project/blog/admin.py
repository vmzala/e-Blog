from django.contrib import admin
from .models import Post,Feedback

admin.site.register(Post)
admin.site.register(Feedback)

